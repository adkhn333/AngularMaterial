module.exports = process.env.SAUCE_ACCESS_KEY.split('').reverse().join('');

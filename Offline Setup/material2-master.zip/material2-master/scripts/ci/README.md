# Continuous Integration Scripts

This directory contains scripts that are related to CI only.

### `build-and-test.sh`

The main script. Setup the tests environment, build the files using the `angular-cli` tool and run the tests.

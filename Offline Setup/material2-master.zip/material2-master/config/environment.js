/* jshint node: true */

module.exports = function(environment) {
  return {
    environment: environment,
    baseURL: '/',
    locationType: 'auto'
  };
};

